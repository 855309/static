import light
import os
import progress
import lightlogger
import math
import shutil
import json

def askq(qu):
    inp = input(":: " + qu + " [y/N] ")

    if inp.lower() == "y":
        lightlogger.log("Removing package...")
        return True
    elif inp.lower() == "n":
        lightlogger.log("Abort.")
        exit()
    elif inp.lower().strip() == "":
        lightlogger.log("Abort.")
        exit()
    else:
        askq(qu)

def get_size(start_path='.'):
    total_size = 0
    for dirpath, dirnames, filenames in os.walk(start_path):
        for f in filenames:
            fp = os.path.join(dirpath, f)
            # skip if it is symbolic link
            if not os.path.islink(fp):
                total_size += os.path.getsize(fp)

    return total_size

def convert_size(size_bytes):
   if size_bytes == 0:
       return "0B"
   size_name = ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
   i = int(math.floor(math.log(size_bytes, 1024)))
   p = math.pow(1024, i)
   s = round(size_bytes / p, 2)
   return "%s %s" % (s, size_name[i])

async def removepackage(packagename):
    dest = "apps/" + packagename

    if not os.path.exists(dest):
        lightlogger.log("App not exists.")
        exit()

    lightlogger.log("Calculating size...")

    size = convert_size(get_size(dest))

    print()

    lightlogger.log(size + " of total space will be deleted.")

    askq("Do you want to continue?")

    shutil.rmtree("apps/" + packagename, ignore_errors=True)

    lightlogger.log("Deleting symlinks...")

    dbo = open("db.json", "r+")
    databasej = dbo.read()

    database = json.loads(databasej)

    mainfile = database["packets"][packagename]["mainfile"]

    os.system("sudo rm -rf /usr/bin/" + mainfile)

    print()

    lightlogger.log("Removed app " + packagename + " successfully.")
