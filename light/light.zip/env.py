repospath = "/usr/share/light/repos"
appspath = "/usr/share/light/apps"
dbpath = "/usr/share/light/db.json"