
repospath = "/usr/share/light/repos"
appspath = "/usr/share/light/apps"
dbpath = "/usr/share/light/db.json"
appdbpath = "/usr/share/light/apps/appdatabase.json"

"""
repospath = "repos"
appspath = "apps"
dbpath = "db.json"
appdbpath = "apps/appdatabase.json"
"""