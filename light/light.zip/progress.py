import os
import light
import git
from git import RemoteProgress
import math

class progressmanager(RemoteProgress):
    def draw(self, valuectl):
        size = os.get_terminal_size().columns

        value = ((size - 7) / 100) * valuectl

        sttr = ""

        print('[', end='')

        ct = 1

        for x in range(1, size - 7):
            if ct <= value:
                sttr += '#'
            else:
                sttr += ' '

            ct += 1

        print(sttr, end='')

        print('] ', end='')

        print(str(valuectl) + "%", end='')

    def update(self, op_code, cur_count, max_count=None, message=''):
        x = math.ceil((100 / max_count) * cur_count)
        
        self.draw(x)

        if x != 100:
            print("\r", end='')
        else:
            print()
