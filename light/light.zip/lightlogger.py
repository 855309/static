import sys

def log(message):
    print(":: " + message)