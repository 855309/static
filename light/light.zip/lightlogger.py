import sys
from termcolor import colored

def log(message):
    print(colored(":: ", "cyan", attrs=["bold"]) + colored(message, "white", attrs=["bold"]))

def inslog(message):
    print(colored("Build -> ", "yellow", attrs=["bold"]) + colored(message, "white", attrs=["bold"]))
