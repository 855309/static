import asyncio
import git
import sys
import json
import light
import os
import progress
import lightlogger
import shutil
import env
import tinydb
import remover

def askq(qu):
    inp = input(":: " + qu + " [Y/n] ")

    if inp.lower() == "y":
        lightlogger.log("Overwriting previous installation.")
        return True
    elif inp.lower() == "n":
        lightlogger.log("Abort.")
        exit()
    elif inp.lower().strip() == "":
        lightlogger.log("Overwriting previous installation.")
        return True
    else:
        askq(qu)

async def installpackage(packagename):
    if not os.path.exists(env.repospath):
        os.mkdir(env.repospath)

    if not os.path.exists(env.appspath):
        os.mkdir(env.appspath)

    if not os.path.exists(env.repospath + "/" + packagename):
        os.mkdir(env.repospath + "/" + packagename)

    if not os.path.exists(env.appspath + "/" + packagename):
        os.mkdir(env.appspath + "/" + packagename)
    else:
        if askq("App already exists. Remove and install again?"):
            await remover.removepackage(packagename)

    dbo = open(env.dbpath, "r+")
    databasej = dbo.read()

    database = json.loads(databasej)

    found = False

    for pk in database["packets"]:
        if pk == packagename:
            found = True
            break

    if not found:
        print("error: Invalid package.")
        light.showhelp()

    repo = database["packets"][packagename]["repo"]
    branch = database["packets"][packagename]["branch"]
    commands = database["packets"][packagename]["commands"]
    outputfiles = database["packets"][packagename]["outputfiles"]
    maindir = database["packets"][packagename]["maindir"]
    mainfile = database["packets"][packagename]["mainfile"]
    ver = database["packets"][packagename]["version"]

    lightlogger.log("Fetching files...")

    git.Repo.clone_from(repo, env.repospath + "/" + packagename, branch=branch, progress=progress.progressmanager())

    lightlogger.log("Done.")

    await asyncio.sleep(1)

    lightlogger.log("Bulding package...")

    comm = "cd " + env.repospath + "/" + packagename + ";cd " + maindir + ";"

    for co in commands:
        lightlogger.inslog(co)
        comm += co + ";"

    os.system(comm)

    await asyncio.sleep(1)

    lightlogger.log("Finished.")

    await asyncio.sleep(1)

    lightlogger.log("Installing...")

    await asyncio.sleep(1)

    cpbase = env.repospath + "/" + packagename + "/" + maindir + "/"

    dest = env.appspath + "/" + packagename + "/"

    for fl in outputfiles:
        if os.path.isdir(cpbase + fl):
            os.system("cp -rf " + cpbase + fl + " " + dest)
        else:
            os.system("cp " + cpbase + fl + " " + dest)

    lightlogger.log("Updating app database...")

    db = tinydb.TinyDB(env.appdbpath)
    qr = tinydb.Query()

    db.insert({
        "name": packagename,
        "version": ver
    })

    lightlogger.log("Cleaning files...")

    await asyncio.sleep(0.5)

    shutil.rmtree(env.repospath + "/" + packagename, ignore_errors=True)

    lightlogger.log("Creating symlink to /usr/bin/" + mainfile)

    os.system("sudo ln -s " + os.path.abspath(dest + mainfile) + " /usr/bin/" + packagename)

    lightlogger.log("App " + packagename + " " + str(ver) + " installed successfully.")