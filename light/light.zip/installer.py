import asyncio
import git
import sys
import json
import light
import os
import progress
import lightlogger
import shutil

def askq(qu):
    inp = input(":: " + qu + " [Y/n] ")

    if inp.lower() == "y":
        lightlogger.log("Overwriting previous installation.")
        return True
    elif inp.lower() == "n":
        lightlogger.log("Abort.")
        exit()
    elif inp.lower().strip() == "":
        lightlogger.log("Overwriting previous installation.")
        return True
    else:
        askq(qu)

async def installpackage(packagename):
    if not os.path.exists("repos"):
        os.mkdir("repos")

    if not os.path.exists("apps"):
        os.mkdir("apps")

    if not os.path.exists("repos/" + packagename):
        os.mkdir("repos/" + packagename)

    if not os.path.exists("apps/" + packagename):
        os.mkdir("apps/" + packagename)
    else:
        if askq("App already exists. Remove and install again?"):
            lightlogger.log("Deleting symlinks...")
            os.system("sudo rm -rf /usr/bin/" + packagename)

    dbo = open("db.json", "r+")
    databasej = dbo.read()

    database = json.loads(databasej)

    found = False

    for pk in database["packets"]:
        if pk == packagename:
            found = True
            break

    if not found:
        print("error: Invalid package.")
        light.showhelp()

    repo = database["packets"][packagename]["repo"]
    branch = database["packets"][packagename]["branch"]
    commands = database["packets"][packagename]["commands"]
    outputfiles = database["packets"][packagename]["outputfiles"]
    maindir = database["packets"][packagename]["maindir"]
    mainfile = database["packets"][packagename]["mainfile"]

    lightlogger.log("Fetching files...")

    git.Repo.clone_from(repo, "repos/" + packagename, branch=branch, progress=progress.progressmanager())

    lightlogger.log("Done.")

    await asyncio.sleep(1)

    lightlogger.log("Bulding package...")

    comm = "cd repos/" + packagename + ";cd " + maindir + ";"

    for co in commands:
        comm += co + ";"

    os.system(comm)

    await asyncio.sleep(1)

    lightlogger.log("Finished.")

    await asyncio.sleep(1)

    lightlogger.log("Installing...")

    await asyncio.sleep(1)

    cpbase = "repos/" + packagename + "/" + maindir + "/"

    dest = "apps/" + packagename + "/"

    for fl in outputfiles:
        if os.path.isdir(cpbase + fl):
            os.system("cp -rf " + cpbase + fl + " " + dest)
        else:
            os.system("cp " + cpbase + fl + " " + dest)

    lightlogger.log("Cleaning files...")

    await asyncio.sleep(0.5)

    shutil.rmtree("repos/" + packagename, ignore_errors=True)

    lightlogger.log("Creating symlink to /usr/bin/" + mainfile)

    os.system("sudo ln -s " + os.path.abspath(dest + mainfile) + " /usr/bin/" + packagename)

    lightlogger.log("App " + packagename + " installed successfully.")
