#!/usr/bin/python3

import asyncio
import sys
import installer
import remover
import requests
import os
import lightlogger
import env
import tinydb
import json

commands = ["install", "remove", "list", "search"]

async def setprogress():
    for x in range(0, 101):
        draw(x)

        if x != 100:
            #term.up(value=1)
            print("\r", end='')
        else:
            print()

        await asyncio.sleep(0.05)

def showhelp():
    print("usage: light [args...]")
    print()
    print("\tinstall:   Downloads and installs a package.")
    print("\tremove:    Removes a installed package.")
    print("\tlist:      Lists all installed packages.")
    print("\tsearch:    Searches for packages.")
    print()
    print("(c) fikret0")
    exit()

def main():
    if len(sys.argv) == 1:
        showhelp()

    if sys.argv[1] not in commands:
        showhelp()

    lightlogger.log("Updating package lists...")

    url = "https://raw.githubusercontent.com/fikret0/static/main/light/db.json"
    output = requests.get(url).text

    if os.path.exists(env.dbpath):
        os.remove(env.dbpath)

    with open(env.dbpath, "w+") as dbf:
        dbf.write(output)

    if sys.argv[1] == "install":
        packagename = sys.argv[2]
        asyncio.run(installer.installpackage(packagename))

    if sys.argv[1] == "remove":
        packagename = sys.argv[2]
        asyncio.run(remover.removepackage(packagename))

    if sys.argv[1] == "list":
        datas = tinydb.TinyDB(env.appdbpath)

        for pkg in datas.all():
            lightlogger.log("Installed: " + pkg["name"] + " " + str(pkg["version"]))

    if sys.argv[1] == "search":
        que = ""

        if len(sys.argv) == 3:
            que = sys.argv[2].lower()

        dbo = open(env.dbpath, "r+")
        databasej = dbo.read()

        database = json.loads(databasej)

        for pkg in database["packets"]:
            if que in pkg.lower():
                lightlogger.log("Found: " + pkg + " " + str(database["packets"][pkg]["version"]))

if __name__ == "__main__":
    main()
