#!/usr/bin/python3

import asyncio
import sys
import installer
import remover
import requests
import os
import lightlogger

commands = ["install", "remove"]

async def setprogress():
    for x in range(0, 101):
        draw(x)

        if x != 100:
            #term.up(value=1)
            print("\r", end='')
        else:
            print()

        await asyncio.sleep(0.05)

def showhelp():
    print("usage: ", sys.argv[0], "[args...]")
    print()
    print("\tinstall:   Downloads and installs a package.")
    print("\tremove:    Removes a installed package.")
    print()
    print("(c) fikret0")
    exit()

def main():
    if len(sys.argv) != 3:
        showhelp()

    if sys.argv[1] not in commands:
        showhelp()

    lightlogger.log("Updating package lists...")

    url = "https://raw.githubusercontent.com/fikret0/static/main/light/db.json"
    output = requests.get(url).text

    if os.path.exists("db.json"):
        os.remove("db.json")

    with open("db.json", "w+") as dbf:
        dbf.write(output)

    if sys.argv[1] == "install":
        packagename = sys.argv[2]
        asyncio.run(installer.installpackage(packagename))

    if sys.argv[1] == "remove":
        packagename = sys.argv[2]
        asyncio.run(remover.removepackage(packagename))

if __name__ == "__main__":
    main()
